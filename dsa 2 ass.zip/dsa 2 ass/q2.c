#include<iostream>
using namespace std;

int merge_arrays(int arr[], int l, int mid, int h){

    int merged[h - l + 1];

    int i = l;
    int j = mid + 1;
    int k = 0;

    int inv_count = 0; // 🔥 count violations

    while(i <= mid && j <= h){

        if(arr[i] <= arr[j]){
            merged[k++] = arr[i++];
        }
        else{
            merged[k++] = arr[j++];
            inv_count += (mid - i + 1); // 🔥 key line
        }
    }

    while(i <= mid){
        merged[k++] = arr[i++];
    }

    while(j <= h){
        merged[k++] = arr[j++];
    }

    // copy back
    for(int x = 0; x < k; x++){
        arr[l + x] = merged[x];
    }

    return inv_count;
}


int merge_sort(int arr[], int l , int h){

    int inv_count = 0;

    if(l < h){
        int mid = (l + h) / 2;

        inv_count += merge_sort(arr, l, mid);
        inv_count += merge_sort(arr, mid + 1, h);
        inv_count += merge_arrays(arr, l, mid, h);
    }

    return inv_count;
}


int main(){

    int n;
    cin >> n;

    int arr[n];
    for(int i = 0; i < n; i++){
        cin >> arr[i];
    }

    int violations = merge_sort(arr, 0, n - 1);

    cout << violations << endl;

    return 0;
}
