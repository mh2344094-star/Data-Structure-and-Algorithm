#include<iostream>
#include<climits>
using namespace std;

struct Result {
    int sum;
    int start;
    int end;
};

Result cross_sum_subarr(int arr[], int l, int mid, int h) {

    int l_sum = INT_MIN;
    int r_sum = INT_MIN;

    int sum = 0;
    int max_left = mid;
    int max_right = mid + 1;

    // left part
    for (int i = mid; i >= l; i--) {
        sum += arr[i];
        if (sum > l_sum) {
            l_sum = sum;
            max_left = i;
        }
    }

    sum = 0;
    // right part
    for (int i = mid + 1; i <= h; i++) {
        sum += arr[i];
        if (sum > r_sum) {
            r_sum = sum;
            max_right = i;
        }
    }

    return {l_sum + r_sum, max_left, max_right};
}

Result max_sum_subarr(int arr[], int l, int h) {

    // base case
    if (l == h) {
        return {arr[l], l, l};
    }

    int mid = (l + h) / 2;

    Result left = max_sum_subarr(arr, l, mid);
    Result right = max_sum_subarr(arr, mid + 1, h);
    Result cross = cross_sum_subarr(arr, l, mid, h);


    if (left.sum >= right.sum && left.sum >= cross.sum)
        return left;
    else if (right.sum >= left.sum && right.sum >= cross.sum)
        return right;
    else
        return cross;
}

int main() {

    int arr[] = {5,4,-1,7,8};
    int n = sizeof(arr) / sizeof(arr[0]);

    Result res = max_sum_subarr(arr, 0, n - 1);

    cout << "Max Sum: " << res.sum << endl;
    cout << "Start Index: " << res.start << endl;
    cout << "End Index: " << res.end << endl;

    return 0;
}
