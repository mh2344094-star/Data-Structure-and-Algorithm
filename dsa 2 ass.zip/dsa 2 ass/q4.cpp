#include<iostream>
using namespace std;

int merge_arrays(int arr[], int l, int mid, int h){

    int count = 0;

    // 🔥 Step 1: Count reverse pairs
    int j = mid + 1;
    for(int i = l; i <= mid; i++){
        while(j <= h && (long long)arr[i] > 2LL * arr[j]){
            j++;
        }
        count += (j - (mid + 1));
    }

    // 🔽 Step 2: Normal merge (your code)
    int merged[h - l + 1];

    int i = l;
    j = mid + 1;
    int k = 0;

    while(i <= mid && j <= h){
        if(arr[i] <= arr[j]){
            merged[k++] = arr[i++];
        }
        else{
            merged[k++] = arr[j++];
        }
    }

    while(i <= mid){
        merged[k++] = arr[i++];
    }

    while(j <= h){
        merged[k++] = arr[j++];
    }

    // copy back
    for(int x = 0; x < k; x++){
        arr[l + x] = merged[x];
    }

    return count;
}


int merge_sort(int arr[], int l , int h){

    int count = 0;

    if(l < h){
        int mid = (l + h) / 2;

        count += merge_sort(arr, l, mid);
        count += merge_sort(arr, mid + 1, h);
        count += merge_arrays(arr, l, mid, h);
    }

    return count;
}


int main(){

    int arr[] = {1,3,2,3,1};
    int n = sizeof(arr)/sizeof(arr[0]);

    int result = merge_sort(arr, 0, n - 1);

    cout << "Reverse pairs: " << result << endl;

    return 0;
}
