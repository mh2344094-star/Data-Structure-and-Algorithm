#include<iostream>
using namespace std;

int partition(int arr[], int l, int h){

    int mid = (l + h) / 2;
    swap(arr[mid], arr[h]);

    int pivot = arr[h];
    int i = l;

    for(int j = l; j < h; j++){
        if(arr[j] <= pivot){
            swap(arr[i], arr[j]);
            i++;
        }
    }

    swap(arr[i], arr[h]);
    return i;
}

int quickselect(int arr[], int l, int h, int k, int n){

    if(l <= h){
        int p = partition(arr, l, h);

        int target = n - k; // kth largest

        if(p == target)
            return arr[p];
        else if(p > target)
            return quickselect(arr, l, p - 1, k, n);
        else
            return quickselect(arr, p + 1, h, k, n);
    }

    return -1; // error case
}

int main(){

    int arr[] = {3,2,3,1,2,4,5,5,6};
    int n = sizeof(arr) / sizeof(arr[0]);

    int k;
    cout<< "input k =";
    cin >> k;

    int result = quickselect(arr, 0, n - 1, k, n);

    cout << "Kth largest element: " << result << endl;

    return 0;
}
